
package programaauditoriadesoftware;

import javax.swing.JOptionPane;


public class ProgramaAuditoriadeSoftware {

    
    public static void main(String[] args) {
        
        Double QtdHorasTrabalhadas;
        Double SalarioBruto;
        Double ValorHora;
        Double PercentDescontoInss; 
        Double DescontoInss;
        Double Fgts;
        Double SalarioLiquido;
 
        System.out.println("Informe quantidade de horas trabalhadas do funcionario ");
        QtdHorasTrabalhadas = Double.parseDouble(JOptionPane.showInputDialog("Informe QtdHorasTrabalhadas"));
 
        System.out.println("Informe o valor por hora que o funcionario recebe ");
        ValorHora = Double.parseDouble(JOptionPane.showInputDialog("Informe ValorHora"));
 
        System.out.println("Informe o % de desconto do INSS ");
        PercentDescontoInss = Double.parseDouble(JOptionPane.showInputDialog("Informe o desconto do INSS"));
        
        System.out.println("Informe o tempo do seu contrato na empresa ");
        Fgts = Double.parseDouble(JOptionPane.showInputDialog("Quantos meses de empresa vocÊ ja tem ? "));
 
        SalarioBruto = (QtdHorasTrabalhadas * ValorHora);
 
        DescontoInss = ( SalarioBruto * PercentDescontoInss)/100;
        
        Fgts = ( SalarioBruto * Fgts);
 
        SalarioLiquido = (SalarioBruto -  DescontoInss);
 
        System.out.println("O salário bruto do funcionário é: " + SalarioBruto);
        System.out.println("O valor do desconto do inss é: " + DescontoInss);
        System.out.println("O Valor do seu FGTS é: " + Fgts);
        System.out.println("O salário líquido  é: " + SalarioLiquido);
    }
    
}
